from fastapi import FastAPI
from pydantic import BaseModel
import requests
import os

API_KEY = "Ix0sTOhgMkx35R71rXXEzo5HeO58uuvq"
app = FastAPI()

class BrowserData(BaseModel):
    ip: str
    user_agent: str
    screen_resolution: str
    timezone: str
    language: str

@app.post("/check_ipqs")
def check_ipqs(data: BrowserData):
    try:
        ip_address = data.ip if data.ip.lower() != "auto" else "8.8.8.8"
        url = f"https://ipqualityscore.com/api/json/ip/{API_KEY}/{ip_address.split(':')[0]}"
        response = requests.get(url, timeout=10)
        ipqs_data = response.json()

        fraud_score = ipqs_data.get('fraud_score', 0)
        risk_score = ipqs_data.get('risk_score', 0)
        residential = ipqs_data.get('residential', False)
        mobile = ipqs_data.get('mobile', False)
        proxy = ipqs_data.get('proxy', False)
        vpn = ipqs_data.get('vpn', False)
        hosting = ipqs_data.get('hosting', False)

        safe = (residential or mobile) and not proxy and not vpn and fraud_score < 30 and risk_score < 30
        recommendation = "SAFE" if safe else "RISKY"

        return {
            "ip": ip_address,
            "fraud_score": fraud_score,
            "risk_score": risk_score,
            "residential": residential,
            "mobile": mobile,
            "proxy": proxy,
            "vpn": vpn,
            "hosting": hosting,
            "recommendation": recommendation,
            "device_fingerprint": {
                "user_agent": data.user_agent,
                "screen_resolution": data.screen_resolution,
                "timezone": data.timezone,
                "language": data.language
            }
        }
    except Exception as e:
        return {"error": str(e)}
